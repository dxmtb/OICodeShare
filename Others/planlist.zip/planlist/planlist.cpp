#include "planlist.h"
#include <QtGui>

Planlist::Planlist(QWidget *parent)
    : QWidget(parent)
{
    QLabel *TimeLabel = new QLabel(tr("Time:"));
    finishDateEdit = new QDateEdit();
    finishDateEdit->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Fixed);
    finishDateEdit->setDisplayFormat(QString("yyyy.MM.dd"));
    finishDateEdit->setDate(QDate::currentDate());

    QLabel *PlanLabel = new QLabel(tr("Plan: "));
    planEdit = new QLineEdit();

    resetButton = new QPushButton(tr("Reset"));
    submitButton = new QPushButton(tr("Submit"));
    saveButton = new QPushButton(tr("Save"));
    loadButton = new QPushButton(tr("Load"));

    planlist = new QTableWidget();
    planlist->setColumnCount(3);
    QStringList *headers = new QStringList();
    (*headers)<<"FinishTime"<<"Plan"<<"AddTime";
    planlist->setHorizontalHeaderLabels(*headers);
    delete(headers);

    connect(resetButton,SIGNAL(clicked()),this,SLOT(reset()));
    connect(submitButton,SIGNAL(clicked()),this,SLOT(submit()));
    connect(saveButton,SIGNAL(clicked()),this,SLOT(savetofile()));
    connect(loadButton,SIGNAL(clicked()),this,SLOT(loadfromfile()));

    QVBoxLayout *rightlayout = new QVBoxLayout;
    rightlayout->addWidget(resetButton);
    rightlayout->addWidget(submitButton);
    rightlayout->addWidget(saveButton);
    rightlayout->addWidget(loadButton);

    QHBoxLayout *upperlayout = new QHBoxLayout;
    upperlayout->addWidget(TimeLabel);
    upperlayout->addWidget(finishDateEdit);

    QHBoxLayout *lowerlayout = new QHBoxLayout;
    lowerlayout->addWidget(PlanLabel);
    lowerlayout->addWidget(planEdit);

    QVBoxLayout *leftlayout = new QVBoxLayout;
    leftlayout->addLayout(upperlayout);
    leftlayout->addLayout(lowerlayout);
    leftlayout->addWidget(planlist);

    QHBoxLayout *mainlayout = new QHBoxLayout;
    mainlayout->addLayout(leftlayout);
    mainlayout->addLayout(rightlayout);

    setLayout(mainlayout);

}

void Planlist::reset()
{
    finishDateEdit->setDate(QDate::currentDate());
    planEdit->clear();
}

void Planlist::resetAll()
{
    planlist->setRowCount(0);
    content.clear();
    reset();
}

void Planlist::submit()
{
    addNewItem(QDate::currentDate(),QDate::currentDate(),planEdit->text());
}

void Planlist::addNewItem(QDate aT,QDate fT,QString pl)
{
    content.push_back(PlanItem(aT,fT,pl));
    const int nowRow = planlist->rowCount();
    planlist->setRowCount(nowRow+1);
    planlist->setItem(nowRow,0,new QTableWidgetItem(fT.toString(QString("yyyy.MM.dd"))));
    planlist->setItem(nowRow,1,new QTableWidgetItem(pl));
    planlist->setItem(nowRow,2,new QTableWidgetItem(aT.toString(QString("yyyy.MM.dd"))));

}

void Planlist::savetofile()
{
    QString fileName = QFileDialog::getSaveFileName(this,
        tr("Save Planlist"), "",
        tr("Planlist (*.plt);;All Files (*)"));

    if (fileName.isEmpty())
        return;
    else {
        QFile file(fileName);

        if (!file.open(QIODevice::WriteOnly)) {
            QMessageBox::information(this, tr("Unable to open file"),
                file.errorString());
            return;
        }

        QDataStream out(&file);
        out.setVersion(QDataStream::Qt_4_7);
        for (QList<PlanItem>::iterator it = content.begin() ;
             it != content.end() ; it++)
                out << it->addTime << it->finishTime << it->plan ;
    }
}

void Planlist::loadfromfile()
{
    QString fileName = QFileDialog::getOpenFileName(this,
        tr("Open Planlist"), "",
        tr("Planlist (*.plt);;All Files (*)"));

    if (fileName.isEmpty())
        return;
    else {
        QFile file(fileName);

        if (!file.open(QIODevice::ReadOnly)) {
            QMessageBox::information(this, tr("Unable to open file"),
                file.errorString());
            return;
        }

        QDataStream in(&file);
        in.setVersion(QDataStream::Qt_4_7);
        resetAll();
        PlanItem temp;
        while(!in.atEnd())
        {
            in >> temp.addTime;
            in >> temp.finishTime;
            in >> temp.plan;
            addNewItem(temp.addTime,temp.finishTime,temp.plan);
        }
    }

}

Planlist::~Planlist()
{

}
