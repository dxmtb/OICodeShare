#ifndef PLANLIST_H
#define PLANLIST_H

#include <QtGui/QWidget>
#include <QDateTime>
#include <QDateEdit>
#include <QTableWidget>

QT_BEGIN_NAMESPACE
class QPushButton;
class QLabel;
class QLineEdit;
QT_END_NAMESPACE

class Planlist : public QWidget
{
    Q_OBJECT

public:

    struct PlanItem
    {
        QDate addTime;
        QDate finishTime;
        QString plan;
        PlanItem(QDate aT,QDate fT,QString pl):
                addTime(aT),finishTime(fT),plan(pl){}
        PlanItem(){}
    };

    Planlist(QWidget *parent = 0);
    ~Planlist();

public slots:

    void reset();
    void submit();
    void savetofile();
    void loadfromfile();
    void resetAll();
    void addNewItem(QDate aT,QDate ft,QString pl);

private:

    QList<PlanItem> content;
    QPushButton *resetButton;
    QPushButton *submitButton;
    QPushButton *loadButton;
    QPushButton *saveButton;
    QLineEdit *planEdit;
    QDateEdit *finishDateEdit;
    QTableWidget *planlist;
};
#endif // PLANLIST_H
