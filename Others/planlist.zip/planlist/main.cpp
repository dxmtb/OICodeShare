#include <QtGui/QApplication>
#include "planlist.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Planlist w;
    w.show();
    return a.exec();
}
